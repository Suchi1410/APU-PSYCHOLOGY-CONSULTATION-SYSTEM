/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package OOPAssignment;

import java.io.BufferedReader;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author Acer User
 */
public class ManageConsultation extends javax.swing.JFrame {

    DefaultTableModel tableModel;

    /**
     * Creates new form ManageConsultation
     */
    public ManageConsultation() {
        initComponents();
        initTableModel();
        loadConsultationsFromFile();

        ConsultationTable.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int selectedRow = ConsultationTable.getSelectedRow();
                if (selectedRow != -1) {
                    fillFieldsFromTable(selectedRow);
                }
            }
        });

    }

    private void initTableModel() {
        tableModel = new DefaultTableModel(new String[]{"RecordID", "Date", "Day", "Time", "Location", "Name"}, 0);
        ConsultationTable.setModel(tableModel);
    }

    private void addConsultationToTable(Consultation consultation) {
        tableModel.addRow(new Object[]{
            consultation.getRecordID(),
            consultation.getDate(),
            consultation.getDay(),
            consultation.getTimeStart() + "-" + consultation.getTimeEnd(),
            consultation.getLocation(),
            consultation.getLecturerName()
        });
    }

    private void updateConsultationInTable(int row, Consultation consultation) {
        tableModel.setValueAt(consultation.getRecordID(), row, 0);
        tableModel.setValueAt(consultation.getDate(), row, 1);
        tableModel.setValueAt(consultation.getDay(), row, 2);
        tableModel.setValueAt(consultation.getTimeStart() + "-" + consultation.getTimeEnd(), row, 3);
        tableModel.setValueAt(consultation.getLocation(), row, 4);
        tableModel.setValueAt(consultation.getLecturerName(), row, 5);
    }

    private void deleteConsultationFromTable(int row) {
        tableModel.removeRow(row);
    }

    private Consultation getConsultationFromFields() {
        String recordID = RecordID.getText();
        String date = ((JTextField) Date.getDateEditor().getUiComponent()).getText();
        String day = Day.getText();
        String timeStart = StartTime.getText().trim();  // Trim any leading/trailing spaces
        String timeEnd = EndTime.getText().trim();      // Trim any leading/trailing spaces

        // Debugging: Log the times
        System.out.println("TimeStart: [" + timeStart + "]");
        System.out.println("TimeEnd: [" + timeEnd + "]");

        String location = (String) Location.getSelectedItem();
        String lecturerName = name.getText();
        return new Consultation(recordID, date, day, timeStart, timeEnd, location, lecturerName);
    }

    private void fillFieldsFromTable(int row) {
        RecordID.setText((String) tableModel.getValueAt(row, 0));
        Date.setDate(java.sql.Date.valueOf((String) tableModel.getValueAt(row, 1)));
        Day.setText((String) tableModel.getValueAt(row, 2));

        // Handle the Time column (e.g., "10:00-11:00")
        String time = (String) tableModel.getValueAt(row, 3);
        if (time.contains("-")) {
            String[] timeParts = time.split("-");
            if (timeParts.length == 2) {
                StartTime.setText(timeParts[0].trim()); // Set Start time (trim whitespace)
                EndTime.setText(timeParts[1].trim());   // Set End time (trim whitespace)
            } else {
                StartTime.setText("");
                EndTime.setText("");
            }
        }

        Location.setSelectedItem(tableModel.getValueAt(row, 4));
        name.setText((String) tableModel.getValueAt(row, 5));
    }

    private void clearFields() {
        RecordID.setText("");
        Date.setDate(null);
        Day.setText("");
        StartTime.setText("");
        EndTime.setText("");
        Location.setSelectedIndex(0);
        name.setText("");
    }

    private void saveConsultationToFile(Consultation consultation) {
        String fileName = "consultations.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            writer.write(consultation.getRecordID() + ","
                    + consultation.getDate() + ","
                    + consultation.getDay() + ","
                    + consultation.getTimeStart() + "-" + consultation.getTimeEnd() + ","
                    + consultation.getLocation() + ","
                    + consultation.getLecturerName());
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving to file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void rewriteConsultationFile() {
        String fileName = "consultations.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                writer.write(tableModel.getValueAt(i, 0) + ","
                        + // RecordID
                        tableModel.getValueAt(i, 1) + ","
                        + // Date
                        tableModel.getValueAt(i, 2) + ","
                        + // Day
                        tableModel.getValueAt(i, 3) + ","
                        + // Time
                        tableModel.getValueAt(i, 4) + ","
                        + // Location
                        tableModel.getValueAt(i, 5));        // Name
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error updating the file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadConsultationsFromFile() {
        String fileName = "consultations.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();  // Trim leading/trailing whitespaces

                // Skip empty lines
                if (line.isEmpty()) {
                    continue;
                }

                String[] data = line.split(",");

                // Ensure the line has the correct number of values (6 columns expected)
                if (data.length == 6) {
                    try {
                        // Create and add the consultation object if the data is valid
                        Consultation consultation = new Consultation(
                                data[0], // RecordID
                                data[1], // Date
                                data[2], // Day
                                data[3].split("-")[0], // Start Time
                                data[3].split("-")[1], // End Time
                                data[4], // Location
                                data[5] // Name
                        );
                        addConsultationToTable(consultation);
                    } catch (Exception e) {
                        // If an error occurs (e.g., malformed date or time), log it
                        System.out.println("Skipping malformed line: " + line);
                    }
                } else {
                    // Log the malformed line if it doesn't contain exactly 6 columns
                    System.out.println("Skipping malformed line (incorrect number of columns): " + line);
                }
            }
        } catch (IOException e) {
            // Handle any IO exceptions
            JOptionPane.showMessageDialog(this, "Error reading from file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        StartTime = new javax.swing.JTextField();
        EndTime = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        Location = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        Day = new javax.swing.JTextField();
        DeleteConsultation = new javax.swing.JButton();
        AddConsultation = new javax.swing.JButton();
        UpdateConsultation = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        RecordID = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        ConsultationTable = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        Date = new com.toedter.calendar.JDateChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(51, 102, 255));

        jLabel7.setFont(new java.awt.Font("Shrikhand", 1, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Consultation Slot");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel2.setText("Date:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel3.setText("Time:");

        StartTime.setBackground(new java.awt.Color(255, 255, 255));
        StartTime.setForeground(new java.awt.Color(0, 0, 0));

        EndTime.setBackground(new java.awt.Color(255, 255, 255));
        EndTime.setForeground(new java.awt.Color(0, 0, 0));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel4.setText("-");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel5.setText("Location:");

        Location.setBackground(new java.awt.Color(255, 255, 255));
        Location.setForeground(new java.awt.Color(0, 0, 0));
        Location.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A-04-15", "B-08-01", "D-07-10", "D-05-10", "E-05-05", " ", " " }));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel6.setText("Day:");

        Day.setBackground(new java.awt.Color(255, 255, 255));

        DeleteConsultation.setBackground(new java.awt.Color(102, 255, 255));
        DeleteConsultation.setForeground(new java.awt.Color(0, 0, 0));
        DeleteConsultation.setText("Delete Consultation");
        DeleteConsultation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteConsultationActionPerformed(evt);
            }
        });

        AddConsultation.setBackground(new java.awt.Color(102, 255, 255));
        AddConsultation.setForeground(new java.awt.Color(0, 0, 0));
        AddConsultation.setText("Add Consultation");
        AddConsultation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddConsultationActionPerformed(evt);
            }
        });

        UpdateConsultation.setBackground(new java.awt.Color(102, 255, 255));
        UpdateConsultation.setForeground(new java.awt.Color(0, 0, 0));
        UpdateConsultation.setText("Update Consultation");
        UpdateConsultation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateConsultationActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel8.setText("RecordID:");

        RecordID.setBackground(new java.awt.Color(255, 255, 255));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel9.setText("Name:");

        name.setBackground(new java.awt.Color(255, 255, 255));
        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });

        ConsultationTable.setBackground(new java.awt.Color(255, 255, 255));
        ConsultationTable.setForeground(new java.awt.Color(0, 0, 0));
        ConsultationTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "RecordID", "Date", "Day", "Time", "Location", "Name"
            }
        ));
        jScrollPane1.setViewportView(ConsultationTable);

        jButton1.setBackground(new java.awt.Color(255, 51, 51));
        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        Date.setBackground(new java.awt.Color(255, 255, 255));
        Date.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(165, 165, 165)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 905, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(AddConsultation, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(53, 53, 53)
                                            .addComponent(Day))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(Location, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel8)
                                            .addGap(18, 18, 18)
                                            .addComponent(RecordID, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addGap(232, 232, 232)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
                                                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(StartTime, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jLabel4)
                                                .addGap(18, 18, 18)
                                                .addComponent(EndTime, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Date, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(62, 62, 62)
                                        .addComponent(UpdateConsultation, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(59, 59, 59)
                                        .addComponent(DeleteConsultation, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 364, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(282, 282, 282)))
                .addContainerGap(134, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addComponent(jButton1)))
                        .addGap(51, 51, 51)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(RecordID, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addGap(42, 42, 42)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Day, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(46, 46, 46)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(Location, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Date, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(42, 42, 42)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(StartTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(EndTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(47, 47, 47)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DeleteConsultation, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AddConsultation, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(UpdateConsultation, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 423, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DeleteConsultationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteConsultationActionPerformed
        int selectedRow = ConsultationTable.getSelectedRow();
        if (selectedRow != -1) {
            deleteConsultationFromTable(selectedRow);
            rewriteConsultationFile(); // Reflect deletion in the file
            clearFields();
            JOptionPane.showMessageDialog(this, "Consultation deleted and file updated!");
        } else {
            JOptionPane.showMessageDialog(this, "No row selected for deletion!");
        }
    }//GEN-LAST:event_DeleteConsultationActionPerformed

    private void AddConsultationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddConsultationActionPerformed
        try {
            Consultation consultation = getConsultationFromFields();
            addConsultationToTable(consultation);
            saveConsultationToFile(consultation); // Append new consultation to file
            clearFields();
            JOptionPane.showMessageDialog(this, "Consultation added successfully!");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_AddConsultationActionPerformed

    private void UpdateConsultationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateConsultationActionPerformed
        int selectedRow = ConsultationTable.getSelectedRow();
        if (selectedRow != -1) {
            try {
                // Debugging: Log the values before creating the Consultation object
                System.out.println("StartTime: " + StartTime.getText());
                System.out.println("EndTime: " + EndTime.getText());

                Consultation consultation = getConsultationFromFields();
                updateConsultationInTable(selectedRow, consultation);
                rewriteConsultationFile(); // Reflect update in the file
                clearFields();
                JOptionPane.showMessageDialog(this, "Consultation updated successfully!");
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to update!", "Update Error", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_UpdateConsultationActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        LecturerHomepage page = new LecturerHomepage();
        page.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nameActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new ManageConsultation().setVisible(true));
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManageConsultation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManageConsultation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManageConsultation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManageConsultation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManageConsultation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddConsultation;
    private javax.swing.JTable ConsultationTable;
    private com.toedter.calendar.JDateChooser Date;
    private javax.swing.JTextField Day;
    private javax.swing.JButton DeleteConsultation;
    private javax.swing.JTextField EndTime;
    private javax.swing.JComboBox<String> Location;
    private javax.swing.JTextField RecordID;
    private javax.swing.JTextField StartTime;
    private javax.swing.JButton UpdateConsultation;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField name;
    // End of variables declaration//GEN-END:variables
}
