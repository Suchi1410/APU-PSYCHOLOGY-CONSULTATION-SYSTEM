/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOPAssignment;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.LocalDate;
/**
 *
 * @author Acer User
 */
public class Appointment {
        private String RecordID;
        private String StudentName;
        private String TPNumber; // Lecturer username (TP number)
        private String Date;
        private String Location;
        private String Time;
        private String Feedback;

        public Appointment(String recordID, String studentName, String tpNumber, String date, String location, String time, String feedback) {
            this.RecordID = recordID;
            this.StudentName = studentName;
            this.TPNumber = tpNumber;
            this.Date = date;
            this.Location = location;
            this.Time = time;
            this.Feedback = feedback;
        }

        public String getRecordID() {
            return RecordID;
        }

        public String getStudentName() {
            return StudentName;
        }

        public String getTPNumber() {
            return TPNumber;
        }

        public String getDate() {
            try {
                LocalDate appointmentDate = LocalDate.parse(this.Date, DateTimeFormatter.ISO_LOCAL_DATE);
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d MMM yyyy");
                return appointmentDate.format(formatter);
            } catch (DateTimeParseException e) {
                System.err.println("Invalid date format: " + this.Date);
                return this.Date; // Return original date string if parsing fails
            }
        }       

        public String getLocation() {
            return Location;
        }
        

        public String getTime() {
            return Time;
        }

        public String getFeedback() {
            return Feedback;
        }

        public void setFeedback(String feedback) {
            this.Feedback = feedback;
        }
}
