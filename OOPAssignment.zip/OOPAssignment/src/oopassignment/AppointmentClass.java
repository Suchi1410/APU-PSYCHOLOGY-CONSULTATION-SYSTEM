package Assignment;

public class AppointmentClass {
    private String recordID;
    private String studentName;
    private String lecturerName;
    private String date;
    private String location;
    private String time;

    public AppointmentClass(String recordID, String studentName, String lecturerName, String date, String location, String time) {
        this.recordID = recordID;
        this.studentName = studentName;
        this.lecturerName = lecturerName;
        this.date = date;
        this.location = location;
        this.time = time;
    }

    public String getRecordID() {
        return recordID;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getLecturerName() {
        return lecturerName;
    }

    public String getDate() {
        return date;
    }

    public String getLocation() {
        return location;
    }

    public String getTime() {
        return time;
    }

    @Override
    public String toString() {
        return "Appointment{" +
                "recordID='" + recordID + '\'' +
                ", studentName='" + studentName + '\'' +
                ", lecturerName='" + lecturerName + '\'' +
                ", date='" + date + '\'' +
                ", location='" + location + '\'' +
                ", time='" + time + '\'' +
                '}';
    }
}
