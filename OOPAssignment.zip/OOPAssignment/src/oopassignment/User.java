
package OOPAssignment;

/**
 *
 * @author Acer User
 */
import java.io.*;

public class User {
    private String name;
    private String username;
    private String password;
    private String role;

    
    public User(String name, String username, String password, String role) {
        this.name = name;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    
    public String getName(){
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getRole() {
        return role;
    }

    public void saveToFile() throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt", true))) {
            writer.write(name + "," + username + "," + password + "," + role + "\n");
            writer.newLine();
        }
    }
    

    public static User validateLogin(String username, String password) throws IOException {
    try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
        String line;
        while ((line = reader.readLine()) != null) {
            // Skip empty or malformed lines
            if (line.trim().isEmpty()) {
                continue;
            }

            String[] details = line.split(",");

            // Ensure the array has exactly 4 elements before accessing indices
            if (details.length != 4) {
                System.out.println("Malformed line in users.txt: " + line);
                continue;
            }

            if (details[1].equals(username) && details[2].equals(password)) {
                return new User(details[0], details[1], details[2], details[3]);
            }
        }
    }
    return null; // No match found
}

}
