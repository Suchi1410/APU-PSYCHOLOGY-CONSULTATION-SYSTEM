/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOPAssignment;

public class Consultation {
    private String recordID;
    private String date;
    private String day;
    private String timeStart;
    private String timeEnd;
    private String location;
    private String lecturername; // Represents the lecturer's name or identifier

    // Constructor
    public Consultation(String recordID, String date, String day, String timeStart, String timeEnd, String location, String lecturername) {
        // Trim any whitespace before assigning values
        this.recordID = recordID;
        this.date = date;
        this.day = day;
        this.timeStart = timeStart.trim();
        this.timeEnd = timeEnd.trim();
        this.location = location;
        this.lecturername = lecturername; // Correct assignment
    }

    // Getters
    public String getRecordID() { return recordID; }
    public String getDate() { return date; }
    public String getDay() { return day; }
    public String getTimeStart() { return timeStart; }
    public String getTimeEnd() { return timeEnd; }
    public String getLocation() { return location; }
    public String getLecturerName() { return lecturername; }

    // Setters
    public void setRecordID(String recordID) { this.recordID = recordID; }
    public void setDate(String date) { this.date = date; }
    public void setDay(String day) { this.day = day; }

    public void setTimeStart(String timeStart) {
        timeStart = timeStart.trim();
        if (!isValidTimeFormat(timeStart)) {
            throw new IllegalArgumentException("Time must be in HH:mm format");
        }
        this.timeStart = timeStart;
    }

    public void setTimeEnd(String timeEnd) {
        timeEnd = timeEnd.trim();
        if (!isValidTimeFormat(timeEnd)) {
            throw new IllegalArgumentException("Time must be in HH:mm format");
        }
        this.timeEnd = timeEnd;
    }

    public void setLocation(String location) { this.location = location; }

    public void setLecturerName(String lecturername) {
        this.lecturername = lecturername; // Correct assignment
    }

    // Utility Method: Validate Time Format
    private boolean isValidTimeFormat(String time) {
        // Validate that the time is in HH:mm format (24-hour clock)
        return time.matches("([01]\\d|2[0-3]):[0-5]\\d");
    }
}
