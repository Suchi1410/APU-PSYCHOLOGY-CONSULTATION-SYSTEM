/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package OOPAssignment;

import javax.swing.*;
import javax.swing.table.*;
import java.io.*;
import java.util.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.ArrayList;


public class ReschedulingRequests extends javax.swing.JFrame {

    // List to hold reschedule requests
    private final List<Request> requests = new ArrayList<>();

    // File to store requests
    private final String FILE_NAME = "reschedule.txt";


    public ReschedulingRequests() {
        initComponents();

        if (rescheduleTable1 == null) {
            rescheduleTable1 = new JTable(new DefaultTableModel(
                new Object[][]{}, // Empty rows
                new String[]{"Record ID", "Date", "Time", "Location", "Lecturer Name", "Student Name", "Suggested Date", "Status"} // Column names
            ));
            JScrollPane scrollPane = new JScrollPane(rescheduleTable1);
            getContentPane().add(scrollPane); // Add the table to the GUI
            System.out.println("rescheduleTable was null. Initialized and added to the GUI.");
        }


        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Rescheduling Requests");

        try {
            loadRescheduleRequests();
            populateTable();
        } catch (Exception e) {
            e.printStackTrace();
        }

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }






    public class Request {

        private String recordID, date, day, time, location, lecturerName, studentName, suggestedDate, status;
        private final SimpleDateFormat inputDateFormat = new SimpleDateFormat("dd/MM/yyyy"); // Assume input is in dd/MM/yyyy format
        private final SimpleDateFormat outputDateFormat = new SimpleDateFormat("d MMM yyyy"); // Desired format

        public Request(String recordID, String date, String time, String location,
               String lecturerName, String studentName, String suggestedDate, String status) {
            this.recordID = recordID;
            this.date = formatDateString(date); // Format the input date
            this.time = time;
            this.location = location;
            this.lecturerName = lecturerName;
            this.studentName = studentName;
            this.suggestedDate = formatDateString(suggestedDate); // Format the suggested date
            this.status = status;

            System.out.println("Created Request: " + toCsv());
        }


        // Format date string to desired format
        private String formatDateString(String dateStr) {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");  // Adjusted to match input date format
            SimpleDateFormat outputFormat = new SimpleDateFormat("d MMM yyyy"); // Desired output format
            try {
                // Parse the input date and format it to the desired output format
                return outputFormat.format(inputFormat.parse(dateStr));
            } catch (ParseException e) {
                System.err.println("Unparseable date: " + dateStr);
                return null; // Return null if the date format is invalid
            }
        }



        public String getRecordID() {
            return recordID;
        }

        public String getDate() {
            return date;
        }

        public String getDay() {
            return day;
        }

        public String getTime() {
            return time;
        }

        public String getLocation() {
            return location;
        }

        public String getLecturerName() {
            return lecturerName;
        }

        public String getStudentName() {
            return studentName;
        }

        public String getSuggestedDate() {
            return suggestedDate;
        }

        public String getStatus() {
            return status;
        }

        // Convert to CSV format
        public String toCsv() {
            return String.join(",",
                    recordID, date, day, time, location, lecturerName, studentName, suggestedDate, status);
        }
    }

    private void ChangeStatusActionPerformed() {
    int selectedRow = rescheduleTable1.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a row to update.", "No Selection", JOptionPane.WARNING_MESSAGE);
        return;
    }

    int columnCount = rescheduleTable1.getColumnCount(); // Get the number of columns
    if (columnCount <= 7) { // Ensure the table has at least 8 columns
        JOptionPane.showMessageDialog(this, "The table does not have enough columns.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Get the current status from the selected row
    String currentStatus = (String) rescheduleTable1.getValueAt(selectedRow, 7); // Column 7 for "Status"

    // Show a dialog to choose a new status
    String[] statusOptions = {"Pending", "Approved", "Disapproved"};
    String newStatus = (String) JOptionPane.showInputDialog(
            this,
            "Select new status:",
            "Change Status",
            JOptionPane.QUESTION_MESSAGE,
            null,
            statusOptions,
            currentStatus); // Default to current status

    if (newStatus != null && !newStatus.equals(currentStatus)) {
        // Update the status in the table
        rescheduleTable1.setValueAt(newStatus, selectedRow, 7); // Column 7 for "Status"

        // Save the updated status to the file
        saveChanges();
    }
}



    private String[] parseCsvLine(String line) {
        String[] fields = line.split(",", -1); // Split by commas
        if (fields.length != 8) {
            System.err.println("Invalid line format: " + line);
            return new String[0]; // Return an empty array for invalid lines
        }
        return fields;
    }



    private void loadRescheduleRequests() {
        File file = new File(FILE_NAME);
        System.out.println("File path: " + file.getAbsolutePath());

        if (!file.exists()) {
            System.err.println("File not found: " + FILE_NAME);
            return;
        }

        requests.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("Read line: " + line);
                String[] details = parseCsvLine(line);
                if (details.length == 8) { // Ensure exactly 8 fields
                    requests.add(new Request(details[0], details[1], details[2], details[3],
                            details[4], details[5], details[6], details[7]));
                } else {
                    System.err.println("Invalid line format: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading requests: " + e.getMessage());
        }
    }




    private void populateTable() {
        if (rescheduleTable1 == null) {
            System.err.println("rescheduleTable is null!");
            return;
        }

        DefaultTableModel model = (DefaultTableModel) rescheduleTable1.getModel();
        model.setRowCount(0); // Clear existing rows

        for (Request request : requests) {
            model.addRow(new Object[]{
                    request.getRecordID(),
                    request.getDate(),
                    request.getTime(),
                    request.getLocation(),
                    request.getLecturerName(),
                    request.getStudentName(),
                    request.getSuggestedDate(),
                    request.getStatus()
            });
        }
    }





    private void saveChanges() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Request request : requests) {
                writer.write(request.toCsv());
                writer.newLine();
            }
            JOptionPane.showMessageDialog(this, "Changes saved successfully!");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving changes: " + e.getMessage(), "Save Error", JOptionPane.ERROR_MESSAGE);
        }
    }



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        rescheduleTable1 = new javax.swing.JTable();
        EditStatus = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(51, 102, 255));

        jButton1.setBackground(new java.awt.Color(255, 51, 51));
        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Shrikhand", 1, 36)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Rescheduling Requests");

        rescheduleTable1.setBackground(new java.awt.Color(255, 255, 255));
        rescheduleTable1.setForeground(new java.awt.Color(0, 0, 0));
        rescheduleTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Record ID", "Date", "Time", "Location", "Lecturer Name", "Student Name", "Suggested Date", "Status"
            }
        ));
        jScrollPane1.setViewportView(rescheduleTable1);

        EditStatus.setBackground(new java.awt.Color(0, 255, 255));
        EditStatus.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        EditStatus.setForeground(new java.awt.Color(0, 0, 0));
        EditStatus.setText("Edit Status");
        EditStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChangeStatusActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(29, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 498, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(174, 174, 174))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(EditStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 844, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 844, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 344, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(EditStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        LecturerHomepage page = new LecturerHomepage();
        page.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void ChangeStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChangeStatusActionPerformed
        int selectedRow = rescheduleTable1.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a row to update.", "No Selection", JOptionPane.WARNING_MESSAGE);
        return;
    }

    // Get the current status from the selected row (column index 7 for "Status")
    String currentStatus = (String) rescheduleTable1.getValueAt(selectedRow, 7); // Column 7 for "Status"

    // Show a dialog to choose a new status
    String[] statusOptions = {"Pending", "Approved", "Disapproved"};
    String newStatus = (String) JOptionPane.showInputDialog(
            this,
            "Select new status:",
            "Change Status",
            JOptionPane.QUESTION_MESSAGE,
            null,
            statusOptions,
            currentStatus); // Default to current status

    if (newStatus != null && !newStatus.equals(currentStatus)) {
        // Update the status in the table (column 7 for "Status")
        rescheduleTable1.setValueAt(newStatus, selectedRow, 7); // Column 7 for "Status"

        // Save the updated status to the file
        saveChanges();
    }
    }//GEN-LAST:event_ChangeStatusActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReschedulingRequests.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReschedulingRequests.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReschedulingRequests.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReschedulingRequests.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReschedulingRequests().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton EditStatus;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable rescheduleTable1;
    // End of variables declaration//GEN-END:variables
}
