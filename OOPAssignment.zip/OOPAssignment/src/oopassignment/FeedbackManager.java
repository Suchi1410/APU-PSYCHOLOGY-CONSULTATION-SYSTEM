import java.io.*;

public class FeedbackManager {

    private static final String FEEDBACK_FILE = "src/Assignment/feedback.txt";

    public static void submitFeedback(String feedback) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FEEDBACK_FILE, true))) {
            writer.write(feedback + "\n");
        }
    }
}
