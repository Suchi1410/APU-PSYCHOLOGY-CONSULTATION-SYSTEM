/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package OOPAssignment;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class UpcomingPastAppointment extends javax.swing.JFrame { 

  // Constructor for UpcomingPastAppointment
    public UpcomingPastAppointment() {
        initComponents();
        loadAppointmentsForLecturer();  // Load appointments for all lecturers
    }




    // Appointment class to store appointment data
    public static class Appointment {
        private String RecordID;
        private String StudentName;
        private String TPNumber; // Lecturer username (TP number)
        private String Date;
        private String Location;
        private String Time;
        private String Feedback;

        public Appointment(String recordID, String studentName, String tpNumber, String date, String location, String time, String feedback) {
            this.RecordID = recordID;
            this.StudentName = studentName;
            this.TPNumber = tpNumber;
            this.Date = date;
            this.Location = location;
            this.Time = time;
            this.Feedback = feedback;
        }

        public String getRecordID() {
            return RecordID;
        }

        public String getStudentName() {
            return StudentName;
        }

        public String getTPNumber() {
            return TPNumber;
        }

        public String getDate() {
            return Date;
        }

        public String getLocation() {
            return Location;
        }

        public String getTime() {
            return Time;
        }

        public String getFeedback() {
            return Feedback;
        }

        public void setFeedback(String feedback) {
            this.Feedback = feedback;
        }

        public boolean isPast() {
            if (this.Date == null || this.Date.trim().isEmpty()) {
        System.err.println("Date is null or empty for RecordID: " + this.RecordID);
        return false;
    }
            System.out.println("Attempting to parse date: '" + this.Date + "' for RecordID: " + this.RecordID);

    try {
        // Use 'd MMM yyyy' to parse dates like '20 Dec 2024'
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH);
        LocalDate appointmentDate = LocalDate.parse(this.Date.trim(), formatter);

        // Debugging: Log the parsed date
        System.out.println("Parsed date: " + appointmentDate + " for RecordID: " + this.RecordID);

        return appointmentDate.isBefore(LocalDate.now()); // Compare with today's date
    } catch (DateTimeParseException e) {
        System.err.println("Error parsing date: '" + this.Date + "' for RecordID: " + this.RecordID);
        return false;
    }
        }
            
 

        public static List<Appointment> getAppointmentsForLecturer() throws IOException {
             List<Appointment> appointments = new ArrayList<>();
    try (BufferedReader reader = new BufferedReader(new FileReader("appointments.txt"))) {
        String line;
        while ((line = reader.readLine()) != null) {
            // Skip empty lines
            if (line.trim().isEmpty()) {
                continue;
            }

            String[] details = line.split(",");

            // Fill in missing fields with default values
            String recordID = details.length > 0 ? details[0] : "";
            String studentName = details.length > 1 ? details[1] : "";
            String tpNumber = details.length > 2 ? details[2] : "";
            String date = details.length > 3 ? details[3] : "";
            String location = details.length > 4 ? details[4] : "";
            String time = details.length > 5 ? details[5] : "";
            String feedback = details.length > 6 ? details[6] : "";

            appointments.add(new Appointment(recordID, studentName, tpNumber, date, location, time, feedback));
        }
    }
    return appointments;
        }
    }
    
    private void setUpcomingTableData(List<Appointment> appointments) {
        DefaultTableModel model = (DefaultTableModel) UpcomingTable.getModel();
    model.setRowCount(0);

    for (Appointment appointment : appointments) {
        model.addRow(new Object[]{
            appointment.getRecordID(),
            appointment.getStudentName(),
            appointment.getTPNumber(),
            appointment.getDate(),
            appointment.getLocation(),
            appointment.getTime()
        });
    }
    }

    private void setPastTableData(List<Appointment> appointments) {
        DefaultTableModel model = (DefaultTableModel) PastTable.getModel();
    model.setRowCount(0);

    for (Appointment appointment : appointments) {
        String feedback = appointment.getFeedback();
        if (feedback == null || feedback.trim().isEmpty()) {
            feedback = "";  // Show an empty string if feedback is missing
        }

        model.addRow(new Object[]{
            appointment.getRecordID(),
            appointment.getStudentName(),
            appointment.getTPNumber(),
            appointment.getDate(),
            appointment.getLocation(),
            appointment.getTime(),
            feedback
        });
    }
    }

    // Move this method to the main UpcomingPastAppointment class
    private void loadAppointmentsForLecturer() {
        try {
            // Load all appointments for all lecturers
            List<Appointment> allAppointments = Appointment.getAppointmentsForLecturer();
            List<Appointment> pastAppointments = new ArrayList<>();
            List<Appointment> upcomingAppointments = new ArrayList<>();

            // Separate the past and upcoming appointments
            for (Appointment appointment : allAppointments) {
                System.out.println("Checking appointment: " + appointment.getDate()); // Print the date for debugging
                if (appointment.isPast()) {
                    pastAppointments.add(appointment);
                } else {
                    upcomingAppointments.add(appointment);
                }
            }

            // Update the tables with the data
            setUpcomingTableData(upcomingAppointments);
            setPastTableData(pastAppointments);
        } catch (IOException e) {
            System.err.println("Error loading appointments: " + e.getMessage());
        }
    }

    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        UpcomingTable = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        PastTable = new javax.swing.JTable();
        AddFeedback = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1000, 1000));
        setSize(new java.awt.Dimension(1000, 1000));

        jPanel1.setBackground(new java.awt.Color(51, 102, 255));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Upcoming Appointment");

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));

        UpcomingTable.setBackground(new java.awt.Color(255, 255, 255));
        UpcomingTable.setForeground(new java.awt.Color(0, 0, 0));
        UpcomingTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "RecordID", "StudentName", "Lecturer Name", "Date", "Location", "Time"
            }
        ));
        jScrollPane1.setViewportView(UpcomingTable);

        jLabel8.setFont(new java.awt.Font("Shrikhand", 1, 36)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Upcoming & Past Appointment");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Past Appointment");

        jScrollPane2.setBackground(new java.awt.Color(255, 255, 255));

        PastTable.setBackground(new java.awt.Color(255, 255, 255));
        PastTable.setForeground(new java.awt.Color(0, 0, 0));
        PastTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "RecordID", "StudentName", "Lecturer Name", "Date", "Location", "Time", "Lecturer Feedback"
            }
        ));
        jScrollPane2.setViewportView(PastTable);

        AddFeedback.setBackground(new java.awt.Color(51, 255, 255));
        AddFeedback.setForeground(new java.awt.Color(0, 0, 0));
        AddFeedback.setText("Add Feedback");
        AddFeedback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddFeedbackActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(255, 51, 51));
        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(270, Short.MAX_VALUE)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 636, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(141, 141, 141))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(98, 98, 98)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 830, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 830, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(AddFeedback)
                                .addGap(15, 15, 15))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jButton1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(AddFeedback, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(86, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AddFeedbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddFeedbackActionPerformed
        int selectedRow = PastTable.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a past appointment to add Lecturer Feedback.");
        return;
    }

    String recordID = PastTable.getValueAt(selectedRow, 0).toString();
    String feedback = JOptionPane.showInputDialog(this, "Enter Lecturer Feedback:");

    if (feedback != null && !feedback.trim().isEmpty()) {
        // Update the Lecturer Feedback column (assumed column index 6)
        PastTable.setValueAt(feedback, selectedRow, 6);

        // Update feedback in the file
        updateFeedback(recordID, feedback);
        JOptionPane.showMessageDialog(this, "Lecturer Feedback added successfully.");
    } else {
        JOptionPane.showMessageDialog(this, "Feedback cannot be empty.");
    }
    }

private void updateFeedback(String recordID, String feedback) {
    File inputFile = new File("appointments.txt");
    File tempFile = new File("appointments_temp.txt");

    try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
         BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

        String line;
        while ((line = reader.readLine()) != null) {
            String[] details = line.split(",");
            if (details.length > 0 && details[0].equals(recordID)) {
                // Handle missing fields
                String recordIDUpdated = details.length > 0 ? details[0] : "";
                String studentName = details.length > 1 ? details[1] : "";
                String tpNumber = details.length > 2 ? details[2] : "";
                String date = details.length > 3 ? details[3] : "";
                String location = details.length > 4 ? details[4] : "";
                String time = details.length > 5 ? details[5] : "";
                
                // Update feedback (ensure it exists in position 6)
                line = String.join(",", recordIDUpdated, studentName, tpNumber, date, location, time, feedback);
            }
            writer.write(line);
            writer.newLine();
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error updating feedback: " + e.getMessage());
    }

    // Replace the original file with the updated file
    if (!inputFile.delete() || !tempFile.renameTo(inputFile)) {
        JOptionPane.showMessageDialog(this, "Error replacing the updated file.");
    }
    }//GEN-LAST:event_AddFeedbackActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        LecturerHomepage page = new LecturerHomepage();
        page.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpcomingPastAppointment().setVisible(true);  // No TPNumber passed
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddFeedback;
    private javax.swing.JTable PastTable;
    private javax.swing.JTable UpcomingTable;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
    }
