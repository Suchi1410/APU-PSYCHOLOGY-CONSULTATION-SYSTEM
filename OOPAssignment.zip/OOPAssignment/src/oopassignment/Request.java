/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOPAssignment;

/**
 *
 * @author Acer User
 */
public class Request {
    private String recordID;
    private String date;
    private String day;
    private String time;
    private String location;
    private String lecturerName;
    private String studentName;
    private String suggestedDate;
    private String status;

    // Constructor
    public Request(String recordID, String date, String day, String time, String location, 
                   String lecturerName, String studentName, String suggestedDate, String status) {
        this.recordID = recordID;
        this.date = date;
        this.day = day;
        this.time = time;
        this.location = location;
        this.lecturerName = lecturerName;
        this.studentName = studentName;
        this.suggestedDate = suggestedDate;
        this.status = status;
    }

    // Getters and setters for each field
    public String getRecordID() { return recordID; }
    public void setRecordID(String recordID) { this.recordID = recordID; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getDay() { return day; }
    public void setDay(String day) { this.day = day; }

    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getLecturerName() { return lecturerName; }
    public void setLecturerName(String lecturerName) { this.lecturerName = lecturerName; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getSuggestedDate() { return suggestedDate; }
    public void setSuggestedDate(String suggestedDate) { this.suggestedDate = suggestedDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
