import java.io.*;

public class AppointmentManager {

    private static final String APPOINTMENT_FILE = "src/Assignment/appointments.txt";

    public static void addAppointment(String[] details) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(APPOINTMENT_FILE, true))) {
            writer.write(String.join(",", details) + "\n");
        }
    }
}
