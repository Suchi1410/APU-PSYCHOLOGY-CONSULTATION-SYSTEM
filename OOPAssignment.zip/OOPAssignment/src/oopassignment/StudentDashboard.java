package OOPAssignment;
import Assignment.AppointmentClass;
import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public class StudentDashboard extends JFrame {

    private final JTable upcomingAppointmentsTable;
    private final DefaultTableModel upcomingAppointmentsTableModel;
    private final JTable pastAppointmentsTable;
    private final DefaultTableModel pastAppointmentsTableModel;
    private final JTable cancelledAppointmentsTable;
    private final DefaultTableModel cancelledAppointmentsTableModel;
    private final JTable rescheduledAppointmentsTable;
    private final DefaultTableModel rescheduledAppointmentsTableModel;
    private final JTable consultationsTable;
    private final DefaultTableModel consultationTableModel;
    private final JTable viewFeedbackTable;
    private final DefaultTableModel viewFeedbackTableModel;
    private DefaultTableModel feedbackTableModel;
    private JComboBox<String> availableConsultationTimes;
    private JTextArea feedbackArea;
    private JList<String> pastAppointmentsList;
    private JTable appointmentsTable;
    private JTextArea feedbackDisplayArea;
    private Map<String, AppointmentClass> pastAppointments = new HashMap<>();

    public StudentDashboard() {
        setTitle("Student Dashboard");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Student Dashboard", JLabel.CENTER);
        titleLabel.setFont(new Font("Roboto", Font.BOLD, 24));
        headerPanel.add(titleLabel, BorderLayout.CENTER);

        JButton logoutButton = new JButton("Logout"); 
        logoutButton.setFont(new Font("Roboto", Font.PLAIN, 14));
        logoutButton.setFocusPainted(false);
        logoutButton.setPreferredSize(new Dimension(100, 40));

        // Set action listener to navigate to the login page
        logoutButton.addActionListener(e -> {
            Login page = new Login(); // Create an instance of the Login page
            page.setVisible(true); // Make the login page visible
            dispose(); // Close the current window
            JOptionPane.showMessageDialog(this, "Logged Out successfully!"); // Show a logout confirmation
        });

headerPanel.add(logoutButton, BorderLayout.EAST);


        add(headerPanel, BorderLayout.NORTH);

        JTabbedPane tabbedPane = new JTabbedPane();

        JPanel consultationsPanel = new JPanel(new BorderLayout());
        String[] consultationColumns = {"Consultation ID", "Date", "Time", "Location", "Lecturer Name"};
        consultationTableModel = new DefaultTableModel(consultationColumns, 0);
        consultationsTable = new JTable(consultationTableModel);
        JScrollPane scrollConsultations = new JScrollPane(consultationsTable);
        consultationsPanel.add(scrollConsultations, BorderLayout.CENTER);
        tabbedPane.addTab("Consultations", consultationsPanel);

        upcomingAppointmentsTableModel = new DefaultTableModel(new String[]{"Record ID", "Student Name", "Lecturer Name", "Date", "Location", "Time"}, 0);
        upcomingAppointmentsTable = new JTable(upcomingAppointmentsTableModel);
        JScrollPane scrollUpcoming = new JScrollPane(upcomingAppointmentsTable);
        tabbedPane.addTab("Upcoming Appointments", scrollUpcoming);

        pastAppointmentsTableModel = new DefaultTableModel(new String[]{"Record ID", "Student Name", "Lecturer Name", "Date", "Location", "Time"}, 0);
        pastAppointmentsTable = new JTable(pastAppointmentsTableModel);
        JScrollPane scrollPast = new JScrollPane(pastAppointmentsTable);
        tabbedPane.addTab("Past Appointments", scrollPast);

        rescheduledAppointmentsTableModel = new DefaultTableModel(new String[]{"Record ID", "Date", "Time", "Location", "Lecturer Name", "Student Name", "Suggested Date", "Status"}, 0);
        rescheduledAppointmentsTable = new JTable(rescheduledAppointmentsTableModel);
        JScrollPane scrollRescheduled = new JScrollPane(rescheduledAppointmentsTable);
        tabbedPane.addTab("Rescheduled Appointments", scrollRescheduled);

        cancelledAppointmentsTableModel = new DefaultTableModel(new String[]{"Record ID", "Student Name", "Lecturer Name", "Date", "Location", "Time"}, 0);
        cancelledAppointmentsTable = new JTable(cancelledAppointmentsTableModel);
        JScrollPane scrollCancelled = new JScrollPane(cancelledAppointmentsTable);
        tabbedPane.addTab("Cancelled Appointments", scrollCancelled);
        
        viewFeedbackTableModel = new DefaultTableModel(new String[]{"Record ID", "Student Name", "Lecturer Name", "Date", "Location", "Time", "Feedback"}, 0);
        viewFeedbackTable = new JTable(viewFeedbackTableModel);
        JScrollPane scrollFeedback = new JScrollPane(viewFeedbackTable);
        tabbedPane.addTab("View Feedback", scrollFeedback);
        add(tabbedPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        JButton bookAppointmentButton = createButton("Book Appointment", new Color(114, 137, 218));
        JButton rescheduleButton = createButton("Reschedule Appointment", new Color(114, 137, 218));
        JButton cancelButton = createButton("Cancel Appointment", new Color(114, 137, 218));
        JButton submitFeedbackButton = createButton("Submit Feedback", new Color(114, 137, 218));
        JButton refreshButton = createButton("Refresh", new Color(114, 137, 218));
        buttonPanel.add(refreshButton);
        buttonPanel.add(bookAppointmentButton);
        buttonPanel.add(rescheduleButton);
        buttonPanel.add(cancelButton);
        buttonPanel.add(submitFeedbackButton);

        add(buttonPanel, BorderLayout.SOUTH);

        feedbackArea = new JTextArea(5, 20);
        feedbackArea.setWrapStyleWord(true);
        feedbackArea.setLineWrap(true);
        feedbackArea.setFont(new Font("Roboto", Font.PLAIN, 14));
        JScrollPane feedbackScroll = new JScrollPane(feedbackArea);

        pastAppointmentsList = new JList<>();
        pastAppointmentsList.setFont(new Font("Roboto", Font.PLAIN, 14));
        JScrollPane pastAppointmentsScroll = new JScrollPane(pastAppointmentsList);

        loadUpcomingAppointments();
        loadConsultationDetails(consultationTableModel);
        loadCancelledAppointments();
        loadFeedbackDetails(viewFeedbackTableModel);

        moveUpcomingToPast();

        bookAppointmentButton.addActionListener(e -> bookAppointment());
        rescheduleButton.addActionListener(e -> rescheduleAppointment());
        cancelButton.addActionListener(e -> cancelAppointment());
        submitFeedbackButton.addActionListener(e -> submitFeedbackForSelectedAppointment());
        refreshButton.addActionListener(e -> refreshPage());

    }
    
private void bookAppointment() {
    int selectedRow = consultationsTable.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a consultation to book an appointment.");
        return;
    }

    String recordId = (String) consultationsTable.getValueAt(selectedRow, 0);
    String date = (String) consultationsTable.getValueAt(selectedRow, 1);
    String time = (String) consultationsTable.getValueAt(selectedRow, 2);
    String location = (String) consultationsTable.getValueAt(selectedRow, 3);
    String lecturerName = (String) consultationsTable.getValueAt(selectedRow, 4);
    String studentName = "Student Name";

    String[] appointmentDetails = {recordId, studentName, lecturerName, date, location, time};

    upcomingAppointmentsTableModel.addRow(appointmentDetails);
    saveToFile("appointments.txt", appointmentDetails);

    JOptionPane.showMessageDialog(this, "Appointment booked successfully!");
}


private void saveToFile(String fileName, String[] details) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
        String line = String.join(",", details);
        writer.write(line);
        writer.newLine();
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error saving to file: " + e.getMessage());
    }
}

private void loadFeedbackDetails(DefaultTableModel viewFeedbackTableModel) {
    File file = new File("feedback.txt");
    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] details = line.split(",");
            if (details.length > 0) {
                String recordId = details[0];
                viewFeedbackTableModel.addRow(new Object[]{recordId});
            }
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error loading feedback: " + e.getMessage());
    }
}
        
    private void loadConsultationDetails(DefaultTableModel consultationTableModel) {
        File file = new File("consultations.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] details = line.split(",");
                consultationTableModel.addRow(details);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading consultations: " + e.getMessage());
        }
    }

private void loadRescheduledAppointments() {
    File file = new File("reschedule.txt");
    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
        String line;
        rescheduledAppointmentsTableModel.setRowCount(0);
        while ((line = reader.readLine()) != null) {
            String[] details = line.split(",");
            if (details.length == 8) { 
                rescheduledAppointmentsTableModel.addRow(details);
            }
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error loading rescheduled appointments: " + e.getMessage());
    }
}
private void rescheduleAppointment() {
    int selectedRow = upcomingAppointmentsTable.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select an appointment to reschedule.");
        return;
    }
    String appointmentId = (String) upcomingAppointmentsTable.getValueAt(selectedRow, 0);
    String currentDate = (String) upcomingAppointmentsTable.getValueAt(selectedRow, 3);
    String currentTime = (String) upcomingAppointmentsTable.getValueAt(selectedRow, 4);
    String currentLocation = (String) upcomingAppointmentsTable.getValueAt(selectedRow, 5);

    JPanel reschedulePanel = new JPanel(new GridLayout(3, 2, 5, 5));

    reschedulePanel.add(new JLabel("New Date:"));
    JDateChooser newDateChooser = new JDateChooser();
    newDateChooser.setDateFormatString("dd/MM/yyyy"); 

    newDateChooser.setDate(new java.util.Date());
    reschedulePanel.add(newDateChooser);


    reschedulePanel.add(new JLabel("New Time:"));
    JTextField newTimeField = new JTextField(currentTime);
    reschedulePanel.add(newTimeField);

    reschedulePanel.add(new JLabel("New Location:"));
    JTextField newLocationField = new JTextField(currentLocation);
    reschedulePanel.add(newLocationField);

    int result = JOptionPane.showConfirmDialog(this, reschedulePanel, "Reschedule Appointment", JOptionPane.OK_CANCEL_OPTION);
    if (result == JOptionPane.OK_OPTION) {
        java.util.Date selectedDate = newDateChooser.getDate();
        String newDate = null;
        if (selectedDate != null) {
            newDate = new java.text.SimpleDateFormat("dd/MM/yyyy").format(selectedDate);
        }
        String newTime = newTimeField.getText().trim();
        String newLocation = newLocationField.getText().trim();
        if (newDate == null || newTime.isEmpty() || newLocation.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.");
        } else {
            String[] rescheduledDetails = {appointmentId, currentDate, currentTime, currentLocation, "Lecturer Name", "Student Name", newDate, "Pending"};
            rescheduledAppointmentsTableModel.addRow(rescheduledDetails);
            saveRescheduledAppointmentToFile(rescheduledDetails);
            JOptionPane.showMessageDialog(this, "Appointment rescheduled successfully!");
        }
    }
}

private void updateAppointment(String appointmentId, String newDate, String newTimeSlot, String newLocation) {
    String[] rescheduledDetails = new String[]{appointmentId, newDate, newTimeSlot, newLocation, "Lecturer Name", "Student Name", "Suggested Date", "Pending"};
    rescheduledAppointmentsTableModel.addRow(rescheduledDetails);
    saveRescheduledAppointmentToFile(rescheduledDetails);
}

private void saveRescheduledAppointmentToFile(String[] appointmentDetails) {
    File file = new File("reschedule.txt");
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
        writer.write(String.join(",", appointmentDetails));
        writer.newLine();
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error saving rescheduled appointment: " + e.getMessage());
    }
}

private void refreshPage() {
    upcomingAppointmentsTableModel.setRowCount(0); 
    loadUpcomingAppointments(); 
    loadRescheduledAppointments(); 
    viewFeedbackTableModel.setRowCount(0);
    loadFeedbackDetails(viewFeedbackTableModel);
    JOptionPane.showMessageDialog(this, "Page refreshed!");
}

    private void cancelAppointment() {
        String[] appointments = getUpcomingAppointmentsArray();
        if (appointments.length == 0) {
            JOptionPane.showMessageDialog(this, "No appointments available to cancel.");
            return;
        }
        JComboBox<String> appointmentDropDown = new JComboBox<>(appointments);
        JPanel panel = new JPanel();
        panel.add(new JLabel("Select Appointment to Cancel"));
        panel.add(appointmentDropDown);

        int result = JOptionPane.showConfirmDialog(this, panel, "Cancel Appointment", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            String selectedAppointment = (String) appointmentDropDown.getSelectedItem();
            cancelAppointmentInTable(selectedAppointment);
        }
    }

    private void cancelAppointmentInTable(String appointmentId) {
        boolean appointmentFound = false;
        for (int i = 0; i < upcomingAppointmentsTableModel.getRowCount(); i++) {
            String id = (String) upcomingAppointmentsTableModel.getValueAt(i, 0);
            if (id.equals(appointmentId)) {
                String[] appointmentDetails = new String[upcomingAppointmentsTableModel.getColumnCount()];
                for (int j = 0; j < upcomingAppointmentsTableModel.getColumnCount(); j++) {
                    appointmentDetails[j] = (String) upcomingAppointmentsTableModel.getValueAt(i, j);
                }
                cancelledAppointmentsTableModel.addRow(appointmentDetails);
                saveCancelledAppointmentToFile(appointmentDetails);
                upcomingAppointmentsTableModel.removeRow(i);
                appointmentFound = true;
                JOptionPane.showMessageDialog(this, "Appointment cancelled successfully!");
                break;
            }
        }
        if (!appointmentFound) {
            JOptionPane.showMessageDialog(this, "Appointment not found.");
        }
    }

    private void loadCancelledAppointments() {
        File file = new File("cancelled.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            cancelledAppointmentsTableModel.setRowCount(0);
            while ((line = reader.readLine()) != null) {
                String[] details = line.split(","); 
                if (details.length == 6) { 
                    cancelledAppointmentsTableModel.addRow(details);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading cancelled appointments: " + e.getMessage());
        }
    }

    private void saveCancelledAppointmentToFile(String[] appointmentDetails) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("cancelled.txt", true))) {
            writer.write(String.join(",", appointmentDetails));
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving cancelled appointment: " + e.getMessage());
        }
    }

    private String[] getUpcomingAppointmentsArray() {
        int rowCount = upcomingAppointmentsTableModel.getRowCount();
        String[] appointments = new String[rowCount];
        for (int i = 0; i < rowCount; i++) {
            appointments[i] = (String) upcomingAppointmentsTableModel.getValueAt(i, 0); 
        }
        return appointments;
    }


    private void submitFeedback() {
        String feedback = JOptionPane.showInputDialog(this, "Please enter your feedback:");
        if (feedback == null || feedback.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter feedback.");
        } else {

            saveFeedbackToFile(feedback);

            JOptionPane.showMessageDialog(this, "Feedback submitted successfully!");
        }
    }

    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setFont(new Font("Roboto", Font.PLAIN, 14));
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(200, 40));
        return button;
    }

    private void loadUpcomingAppointments() {
        try (BufferedReader reader = new BufferedReader(new FileReader("appointments.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",", -1);
                if (data.length == 7) { 
                    upcomingAppointmentsTableModel.addRow(data);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading upcoming appointments: " + e.getMessage());
        }
    }

    private void moveUpcomingToPast() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d MMM yyyy");
        LocalDate currentDate = LocalDate.now();

        List<String[]> pastAppointments = new ArrayList<>();
        List<Integer> rowsToRemove = new ArrayList<>();

        for (int i = 0; i < upcomingAppointmentsTableModel.getRowCount(); i++) {
            String dateStr = (String) upcomingAppointmentsTableModel.getValueAt(i, 3);

            try {
                LocalDate appointmentDate = LocalDate.parse(dateStr.trim(), formatter);

                if (appointmentDate.isBefore(currentDate)) {
                    String[] appointmentDetails = new String[upcomingAppointmentsTableModel.getColumnCount() + 1];
                    for (int j = 0; j < upcomingAppointmentsTableModel.getColumnCount(); j++) {
                        appointmentDetails[j] = (String) upcomingAppointmentsTableModel.getValueAt(i, j);
                    }
                    pastAppointmentsTableModel.addRow(appointmentDetails);
                    rowsToRemove.add(i);
                }
            } catch (DateTimeParseException e) {
                System.out.println("Error parsing date: " + dateStr);
            }
        }

        for (int i = rowsToRemove.size() - 1; i >= 0; i--) {
            upcomingAppointmentsTableModel.removeRow(rowsToRemove.get(i));
        }

        for (String[] appointment : pastAppointments) {
            pastAppointmentsTableModel.addRow(appointment);
        }
    }


private void submitFeedbackForSelectedAppointment() {
        int selectedRow = pastAppointmentsTable.getSelectedRow();

        if (selectedRow != -1) {
            String recordId = (String) pastAppointmentsTable.getValueAt(selectedRow, 0);
            String studentName = (String) pastAppointmentsTable.getValueAt(selectedRow, 1);
            String lecturerName = (String) pastAppointmentsTable.getValueAt(selectedRow, 2);
            String date = (String) pastAppointmentsTable.getValueAt(selectedRow, 3);
            String location = (String) pastAppointmentsTable.getValueAt(selectedRow, 4);
            String time = (String) pastAppointmentsTable.getValueAt(selectedRow, 5);

            String feedback = JOptionPane.showInputDialog(this, "Enter feedback for this appointment:");

            if (feedback != null && !feedback.trim().isEmpty()) {
                String feedbackRecord = String.format("Appointment ID: %s, Student: %s, Lecturer: %s, Date: %s, Location: %s, Time: %s, Feedback: %s",
                        recordId, studentName, lecturerName, date, location, time, feedback);

                saveFeedbackToFile(feedbackRecord);

                JOptionPane.showMessageDialog(this, "Feedback submitted successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Feedback cannot be empty.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an appointment to provide feedback.");
        }
    }

private void saveFeedbackToFile(String feedback) {
    File file = new File("feedback.txt");
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
        writer.write(feedback);
        writer.newLine();
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error saving feedback: " + e.getMessage());
    }
}
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StudentDashboard studentDashboard = new StudentDashboard();
            studentDashboard.setSize(800, 600);
            studentDashboard.setVisible(true);
        });
    }

    private void moveToCancelledAppointmentsTable(String appointmentId) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
